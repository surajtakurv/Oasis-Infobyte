const temperatureInput = document.getElementById('temperature');
const unitSelect = document.getElementById('unit');
const convertButton = document.getElementById('convert');
const resultDiv = document.getElementById('result');

convertButton.addEventListener('click', function(event) {
    event.preventDefault(); // Add this line to prevent form submission
    convertTemperature();
});

function convertTemperature() {
    const temperature = parseFloat(temperatureInput.value);
    const unit = unitSelect.value;

    if (isNaN(temperature)) {
        alert('Please enter a valid temperature');
        return;
    }

    let convertedTemperature;
    let convertedUnit;

    switch (unit) {
        case 'Celsius':
            convertedTemperature = temperature * 9/5 + 32;
            convertedUnit = 'Fahrenheit';
            break;
        case 'Fahrenheit':
            convertedTemperature = (temperature - 32) * 5/9;
            convertedUnit = 'Celsius';
            break;
        case 'Kelvin':
            convertedTemperature = temperature - 273.15;
            convertedUnit = 'Celsius';
            break;
    }

    resultDiv.innerHTML = `The converted temperature is ${convertedTemperature.toFixed(2)} ${convertedUnit}`;
}